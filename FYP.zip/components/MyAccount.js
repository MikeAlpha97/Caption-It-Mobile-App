/* eslint-disable react-native/no-inline-styles */
import 'react-native-gesture-handler';
import React, {Component} from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  TouchableOpacity,
  Image,
} from 'react-native';

export default function MyAccount({navigation}) {
  return (
    <View>
      <View style={styles.ImgView}>
        <Image
          source={require('../assets/blank-dp.png')}
          style={styles.ImgProfile}
        />
      </View>
      <Text style={{textAlign: 'center'}}> USERNAME </Text>
      <Text style={{textAlign: 'center', fontSize: 10}}> user@gmail.com </Text>
      <View style={styles.btnView}>
        <Button
          color="#B2D649"
          title="View Saved Posts"
          onPress={() => navigation.navigate('SavedPosts')}
        />
      </View>
      <View style={styles.btnView}>
        <Button
          color="#FF884A"
          title="Update Profile"
          onPress={() => navigation.navigate('UpdateProfile')}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  ImgProfile: {
    height: 100,
    width: 100,
    borderWidth: 1,
    borderColor: 'pink',
    borderRadius: 50,
  },
  ImgView: {
    alignItems: 'center',
    padding: 20,
    marginTop: 20,
  },
  btnView: {
    alignSelf: 'center',
    marginTop: 50,
  },
});
