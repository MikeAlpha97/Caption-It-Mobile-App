/* eslint-disable react-native/no-inline-styles */
import 'react-native-gesture-handler';
import React, {Component} from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  CheckBox,
  TouchableOpacity,
} from 'react-native';

export default class Settings extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      toggle: true,
    };
  }

  toggleTheme() {
    this.setState({
      toggle: this.state.toggle ? false : true,
    });
  }
  render() {
    return (
      <View
        style={[
          styles.container,
          {backgroundColor: this.state.toggle ? 'white' : 'black'},
        ]}>
        <TouchableOpacity onPress={() => this.toggleTheme()}>
          <Text
            style={[
              styles.text,
              {color: this.state.toggle ? 'black' : 'white'},
            ]}>
            Click for Dark Mode
          </Text>
        </TouchableOpacity>
        <View
          style={{
            borderBottomColor: 'black',
            borderBottomWidth: 1,
            marginTop: 50,
          }}
        />
        <View
          style={{
            borderBottomColor: 'black',
            borderBottomWidth: 1,
            marginTop: 2,
          }}
        />
        {/* <View
          style={{
            flexDirection: 'row',
            paddingHorizontal: 30,
            marginTop: 10,
            justifyContent: 'space-between',
          }}>
          <Text>Notifications</Text>
          <CheckBox />
        </View> */}
        <View
          style={{
            borderBottomColor: 'black',
            borderBottomWidth: 1,
            marginTop: 7,
          }}
        />
        {/* <View
          style={{
            flexDirection: 'row',
            paddingHorizontal: 30,
            marginTop: 10,
            justifyContent: 'space-between',
          }}>
          <Text>Dark Mode</Text>
          <CheckBox />
        </View> */}
        <View
          style={{
            borderBottomColor: 'black',
            borderBottomWidth: 1,
            marginTop: 7,
          }}
        />
        {/* <View
          style={{
            flexDirection: 'row',
            paddingHorizontal: 30,
            marginTop: 10,
            justifyContent: 'space-between',
          }}>
          <Text>Popups</Text>
          <CheckBox />
        </View> */}
        <View
          style={{
            borderBottomColor: 'black',
            borderBottomWidth: 1,
            marginTop: 7,
          }}
        />
        <View
          style={{
            flexDirection: 'row',
            paddingHorizontal: 30,
            marginTop: 10,
            justifyContent: 'space-between',
          }}>
          <TouchableOpacity>
            <Text
              style={[
                styles.text,
                {color: this.state.toggle ? 'black' : 'white'},
              ]}>
              Rate the App
            </Text>
          </TouchableOpacity>
        </View>
        <View
          style={{
            borderBottomColor: 'black',
            borderBottomWidth: 1,
            marginTop: 16,
          }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 20,
    fontWeight: 'bold',
  },
});
