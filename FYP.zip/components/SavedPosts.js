import 'react-native-gesture-handler';
import React, {Component} from 'react';
import {Text, View, StyleSheet, Button, Image} from 'react-native';
import {ScrollView} from 'react-native-gesture-handler';

export default function SavedPosts({navigation}) {
  return (
    <ScrollView>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/icon.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 3</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/dummy.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 5,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/img2.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 13,2020</Text>
          <Text style={styles.txted}>Rating : 4</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/img4.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Feb 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/img3.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
      <View style={{flexDirection: 'row'}}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View>
          <Text style={styles.txte}>Date: Jan 1,2020</Text>
          <Text style={styles.txted}>Rating : 5</Text>
          <Text style={styles.txte}>Caption:</Text>
          <Text style={styles.txtemail}>'text for caption generated here'</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  ImgProfile: {
    height: 120,
    width: 120,
    borderWidth: 2,
    borderColor: 'black',
  },
  ImgView: {
    padding: 10,
  },
  btnView: {
    alignSelf: 'center',
    padding: 20,
    marginTop: 10,
    marginLeft: 10,
  },
  view1: {
    paddingHorizontal: 10,
    flexDirection: 'row',
  },
  txte: {
    fontWeight: 'bold',
    alignItems: 'center',
    fontSize: 15,
    marginLeft: 10,
    marginRight: 40,
    marginTop: 10,
  },
  txted: {
    fontStyle: 'italic',
    alignItems: 'center',
    fontSize: 15,
    marginLeft: 10,
    marginRight: 40,
    marginTop: 10,
  },
  txtemail: {
    alignItems: 'center',
    marginLeft: 10,
    marginTop: 10,
  },
});
