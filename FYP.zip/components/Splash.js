import 'react-native-gesture-handler';
import React, {Component} from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  ImageBackground,
  Image,
} from 'react-native';
import {LoginButton, AccessToken} from 'react-native-fbsdk';

export default function Splash({navigation}) {
  return (
    <ImageBackground
      source={require('../assets/img3.png')}
      style={styles.mainView}>
      <View style={styles.Logo}>
        <Image source={require('../assets/icons8.png')} style={styles.img1} />
        <Text style={styles.txtStyl}>Caption It'</Text>
        <Text
          style={{
            color: 'white',
            alignContent: 'center',
            marginLeft: 15,
            fontSize: 15,
            fontWeight: 'bold',
            color: 'black',
          }}>
          Generate Amazing Captions!
        </Text>
      </View>
      <View style={styles.buttonFb}>
        <LoginButton
          onLoginFinished={(error, result) => {
            if (error) {
              console.log('login has error: ' + result.error);
            } else if (result.isCancelled) {
              console.log('login is cancelled.');
            } else {
              AccessToken.getCurrentAccessToken().then(data => {
                console.log(data.accessToken.toString());
              });
            }
          }}
          onLogoutFinished={() => console.log('logout.')}
        />
      </View>
      <View style={styles.buttonNormal}>
        <View style={{marginRight: 30}}>
          <Button
            color="#141D27"
            title="SignUp"
            onPress={() => navigation.navigate('SignUp')}
          />
        </View>
        <View>
          <Button
            color="#141D27"
            title="SignIn"
            onPress={() => navigation.navigate('SignIn')}
          />
        </View>
      </View>
      <View style={{padding:10}}>
        <Button
          color="#141D27"
          title="Use as Guest"
          onPress={() => navigation.navigate('Welcome')}
        />
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    alignItems: 'center',
  },
  Logo: {
    marginTop: 15,
    padding: 0,
    marginBottom: 90,
  },
  buttonFb: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 60,
    marginTop: 30,
    marginBottom: 10,
  },
  buttonNormal: {
    flex: 3,
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  txtStyl: {
    fontWeight: 'bold',
    fontSize: 40,
    marginTop: 0,
    marginLeft: 20,
    alignContent: 'center',
    justifyContent: 'center',
    marginBottom: 0,
    color: 'white',
  },
  img1: {
    alignContent: 'flex-start',
    marginBottom: 0,
    marginTop: 10,
    scaleX: 1,
    scaleY: 1,
  },
  btntxtStyl: {
    color: 'white',
    fontStyle: 'italic',
  },
});
