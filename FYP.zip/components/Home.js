import 'react-native-gesture-handler';
import React, {Component} from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  TouchableOpacity,
  TouchableHighlight,
  Image,
  ScrollView,
  ImageBackground,
} from 'react-native';

export default function Home({navigation}) {
  return (
    <View style={styles.parentView}>
      <Image source={require('../assets/well.png')} style={styles.imagee} />
      <View style={{flex: 1, flexDirection: 'row'}}>
        <TouchableHighlight onPress={() => navigation.navigate('CaptionIt')}>
          <View style={styles.button}>
            <Text style={styles.optionsText}>Caption It</Text>
          </View>
        </TouchableHighlight>
        <TouchableHighlight onPress={() => navigation.navigate('SavedPosts')}>
          <View style={styles.button}>
            <Text style={styles.optionsText}> Favourites </Text>
          </View>
        </TouchableHighlight>
      </View>
      <View style={{flex: 1, flexDirection: 'row'}}>
        <TouchableHighlight onPress={() => navigation.navigate('Settings')}>
          <View style={styles.button}>
            <Text style={styles.optionsText}>Settings </Text>
          </View>
        </TouchableHighlight>
        <TouchableHighlight onPress={() => navigation.navigate('MyAccount')}>
          <View style={styles.button2}>
            <Text style={styles.optionsText}>My Account</Text>
          </View>
        </TouchableHighlight>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  btnView: {
    flexDirection: 'column',
    padding: 10,
    backgroundColor: '#F7F7F9',
    marginBottom: 20,
    marginTop: 10,
  },

  text: {
    marginTop: 0,
    textAlign: 'left',
    fontSize: 25,
    fontFamily: 'Roboto',
    color: '#F7F7F9',
    fontWeight: 'bold',
  },
  imgView: {
    height: 35,
    width: 35,
    right: -130,
  },
  topacity: {
    backgroundColor: '#D2302C',
    height: 75,
    width: 325,
    padding: 10,
    marginVertical: 10,
    flexDirection: 'row',
    borderRadius: 30,
  },
  imagee: {
    height: 250,
    width: 360,
    alignSelf: 'center',
  },
  textOnImage: {
    color: 'black',
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 70,
  },
  parentView: {
    flex: 1,
    flexDirection: 'column',
  },
  button: {
    alignItems: 'center',
    backgroundColor: '#17202A',
    padding: 45,
    alignSelf: 'stretch',
    paddingVertical: 66,
  },
  button2: {
    alignItems: 'center',
    backgroundColor: '#17202A',
    padding: 47,
    alignSelf: 'stretch',
    paddingVertical: 66,
  },
  optionsText: {
    color: 'white',
    fontFamily: 'sans-serif-thin',
    fontSize: 20,
  },
});
