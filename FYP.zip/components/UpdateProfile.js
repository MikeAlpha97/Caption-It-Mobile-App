import 'react-native-gesture-handler';
import React, {Component} from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  Image,
  Alert,
  ScrollView,
} from 'react-native';

export default function UpdateProfile({navigation}) {
  return (
    <ScrollView>
      <View style={styles.view1}>
        <View style={styles.ImgView}>
          <Image
            source={require('../assets/blank-dp.png')}
            style={styles.ImgProfile}
          />
        </View>
        <View style={styles.btnView}>
          <Button
            color="#FF006C"
            title="Update"
            onPress={() => Alert.alert('cannot update profile photo')}
          />
        </View>
      </View>
      <View style={styles.view1}>
        <Text style={styles.txte}>First Name</Text>
        <View style={styles.btnView}>
          <Button
            color="#FF006C"
            title="Update"
            onPress={() => Alert.alert('cannot update first name')}
          />
        </View>
      </View>
      <View style={styles.view1}>
        <Text style={styles.txte}>Last Name</Text>
        <View style={styles.btnView}>
          <Button
            color="#FF006C"
            title="Update"
            onPress={() => Alert.alert('cannot update last name')}
          />
        </View>
      </View>
      <View style={styles.view1}>
        <Text style={styles.txtemail}>user@gmail.com</Text>
        <View style={styles.btnView}>
          <Button
            color="#FF006C"
            title="Update"
            onPress={() => Alert.alert('cannot update email')}
          />
        </View>
      </View>
      <View style={styles.btnView}>
        <Button
          color="#FF006C"
          title="Clear Posts"
          onPress={() => Alert.alert('cannot clear posts')}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  ImgProfile: {
    height: 120,
    width: 120,
    borderWidth: 1,
    borderColor: 'pink',
    borderRadius: 60,
    marginRight: 15,
  },
  ImgView: {
    alignItems: 'center',
    padding: 20,
    marginTop: 20,
  },
  btnView: {
    alignSelf: 'center',
    padding: 20,
    marginTop: 10,
    marginLeft: 10,
  },
  view1: {
    paddingHorizontal: 10,
    flexDirection: 'row',
  },
  txte: {
    fontWeight: 'bold',
    alignItems: 'center',
    fontSize: 17,
    padding: 20,
    marginLeft: 10,
    marginRight: 40,
    marginTop: 10,
  },
  txtemail: {
    alignItems: 'center',
    fontSize: 15,
    padding: 20,
    marginLeft: 10,
    marginRight: 8,
    marginTop: 10,
  },
});
