import 'react-native-gesture-handler';
import React, {Component} from 'react';
import {Text, View, StyleSheet, Button, TextInput} from 'react-native';
import Icon from 'react-native-vector-icons/dist/FontAwesome';

export default function SignUp({navigation}) {
  return (
    <View
      style={{
        marginTop: 30,
        marginLeft: 10,
        marginRight: 10,
        alignContent: 'center',
      }}>
      <Icon
        name="remove"
        size={30}
        color="#FF006C"
        onPress={() => navigation.goBack()}
      />
      <Text
        style={{
          marginTop: 30,
          alignSelf: 'center',
          fontSize: 20,
          fontWeight: 'bold',
          color: '#FF006C',
        }}>
        Create an Account
      </Text>

      <View>
        <TextInput placeholder="First Name" style={styles.input} />
        <TextInput placeholder="Last Name" style={styles.input} />
        <TextInput placeholder="Email" style={styles.input} />
        <TextInput
          placeholder="Password"
          style={styles.input}
          secureTextEntry={true}
        />
      </View>
      <View style={styles.button}>
        <Button
          color="#FF006C"
          title="SignUp"
          onPress={() => navigation.navigate('Welcome')}
        />
      </View>
      <Text style={styles.text}>
        By pressing Sign Up you agree with Terms and Services and Privacy Policy
      </Text>
      <View style={styles.button}>
        <Button
          color="#FF006C"
          title="Already have an account?"
          onPress={() => navigation.navigate('SignIn')}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    height: 40,
    marginTop: 15,
    marginLeft: 50,
    marginRight: 50,
    paddingVertical: 5,
    paddingHorizontal: 20,
    fontSize: 14,
    backgroundColor: 'lightgrey',
    borderRadius: 5,
  },
  button: {
    color: 'purple',
    height: 40,
    marginTop: 15,
    marginLeft: 30,
    marginRight: 30,
    paddingVertical: 5,
    paddingHorizontal: 20,
    fontSize: 20,
    borderRadius: 5,
  },
  text: {
    marginTop: 0,
    textAlign: 'center',
    marginLeft: 30,
    marginRight: 30,
    paddingVertical: 5,
    paddingHorizontal: 20,
    fontSize: 8,
    color: 'grey',
  },
});
